# Fashion E-commerce Product Management Platform

## Overview

This is a full-stack fashion e-commerce platform specifically designed for product management, featuring a comprehensive "Add Product" interface inspired by Daraz's seller dashboard. The application is built with a modern tech stack using React, TypeScript, Express.js, and PostgreSQL with Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: TailwindCSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Pattern**: RESTful API design
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple

## Key Components

### 1. Product Management System
The core feature is a comprehensive product creation interface with:
- **Category Selection**: Multi-level hierarchical category tree (Fashion > Gender > Type > Subcategory)
- **Image Management**: Upload up to 7 images with editing capabilities (crop, background removal, rotation)
- **Variant Management**: Color and size variants with pricing and inventory tracking
- **Content Scoring**: Real-time content quality assessment
- **Rich Text Editor**: WYSIWYG editor for product descriptions

### 2. Data Models
- **Products**: Comprehensive product schema with categories, variants, images, and metadata
- **Users**: Basic user authentication system
- **Categories**: Hierarchical fashion category structure
- **Variants**: Color/size combinations with individual pricing and stock levels

### 3. UI Component System
- Complete Shadcn/ui component library implementation
- Custom components for product-specific functionality
- Responsive design optimized for both desktop and mobile
- Dark/light theme support through CSS variables

## Data Flow

### Product Creation Flow
1. **Category Selection**: User navigates through hierarchical category tree
2. **Basic Information**: Product name, brand, description entry
3. **Image Upload**: Multiple image upload with editing tools
4. **Variant Configuration**: Color and size matrix with pricing
5. **Content Validation**: Real-time scoring and validation
6. **Submission**: Draft saving and final submission workflow

### State Management
- **Local Storage**: Auto-save draft functionality for form persistence
- **Server State**: TanStack Query manages API calls and caching
- **Form State**: React Hook Form handles complex form validation and submission

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe ORM with PostgreSQL support
- **@tanstack/react-query**: Server state management
- **@radix-ui/**: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **zod**: Schema validation library

### Development Tools
- **drizzle-kit**: Database migrations and schema management
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations stored in `migrations/` directory

### Environment Configuration
- **Development**: Uses tsx for hot reloading and Vite dev server
- **Production**: Compiled Node.js server serving static assets
- **Database**: Configured via `DATABASE_URL` environment variable

### Project Structure
```
├── client/          # Frontend React application
├── server/          # Express.js backend
├── shared/          # Shared types and schemas
├── migrations/      # Database migration files
└── dist/           # Production build output
```

The application follows a monorepo structure with clear separation between client, server, and shared code, enabling efficient development and deployment workflows.