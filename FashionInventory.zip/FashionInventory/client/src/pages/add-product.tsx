import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Save, Send } from "lucide-react";
import { CategorySelector } from "@/components/category-selector";
import { ImageUpload } from "@/components/image-upload";
import { VariantTable } from "@/components/variant-table";
import { ContentScore } from "@/components/content-score";
import { RichTextEditor } from "@/components/rich-text-editor";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertProduct } from "@shared/schema";

interface ProductFormData {
  name: string;
  category: string[];
  brand: string;
  description: string;
  highlights: string[];
  images: Array<{ url: string; isWhiteBackground?: boolean }>;
  colors: Array<{ name: string; hex: string }>;
  sizes: Array<{ size: string; bodyPart: string; unit: string; value: number }>;
  variants: Array<{ color: string; size: string; price: number; specialPrice?: number; stock: number; sku: string; available: boolean }>;
}

export default function AddProduct() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useLocalStorage<ProductFormData>("product-draft", {
    name: "",
    category: [],
    brand: "",
    description: "",
    highlights: ["", "", ""],
    images: [],
    colors: [],
    sizes: [],
    variants: []
  });

  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  // Auto-save every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setLastSaved(new Date());
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const createProductMutation = useMutation({
    mutationFn: async (data: { product: InsertProduct; status: "draft" | "submitted" }) => {
      const response = await apiRequest("POST", "/api/products", {
        ...data.product,
        status: data.status
      });
      return response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: variables.status === "draft" ? "Draft saved" : "Product submitted",
        description: variables.status === "draft" 
          ? "Your product has been saved as a draft" 
          : "Your product has been submitted for review"
      });
      
      // Clear draft if submitted
      if (variables.status === "submitted") {
        localStorage.removeItem("product-draft");
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save product. Please try again.",
        variant: "destructive"
      });
    }
  });

  const updateFormData = (updates: Partial<ProductFormData>) => {
    setFormData((prev: ProductFormData) => ({ ...prev, ...updates }));
  };

  const handleSaveDraft = () => {
    const productData: InsertProduct = {
      name: formData.name,
      category: formData.category,
      brand: formData.brand || null,
      description: formData.description,
      highlights: formData.highlights.filter((h: string) => h.trim()),
      images: formData.images,
      colors: formData.colors,
      sizes: formData.sizes,
      variants: formData.variants
    };

    createProductMutation.mutate({ product: productData, status: "draft" });
  };

  const handleSubmit = () => {
    const productData: InsertProduct = {
      name: formData.name,
      category: formData.category,
      brand: formData.brand || null,
      description: formData.description,
      highlights: formData.highlights.filter((h: string) => h.trim()),
      images: formData.images,
      colors: formData.colors,
      sizes: formData.sizes,
      variants: formData.variants
    };

    createProductMutation.mutate({ product: productData, status: "submitted" });
  };

  const getContentScore = () => {
    const criteria = [
      formData.name.length > 0,
      formData.images.length >= 3,
      formData.brand.length > 0,
      formData.category.length > 0,
      formData.colors.length > 0 && formData.sizes.length > 0,
      formData.description.trim().split(/\s+/).length >= 30,
      formData.highlights.filter((h: string) => h.trim()).length >= 3
    ];
    
    const completed = criteria.filter(Boolean).length;
    return Math.round((completed / criteria.length) * 100);
  };

  return (
    <div className="min-h-screen bg-muted/20">
      {/* Header */}
      <header className="bg-background border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <h1 className="text-xl font-semibold">Add New Product</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">Preview</Button>
              {lastSaved && (
                <div className="text-sm text-muted-foreground">
                  Auto-saved {lastSaved.toLocaleTimeString()}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-6">
          {/* Main Content */}
          <div className="flex-1 space-y-6">
            {/* Category Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Product Category *
                  {formData.category.length > 0 && (
                    <span className="text-sm font-normal text-muted-foreground">
                      {formData.category.join(" > ")}
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CategorySelector
                  selectedCategory={formData.category}
                  onCategorySelect={(category: string[]) => updateFormData({ category })}
                />
              </CardContent>
            </Card>

            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="productName">Product Name *</Label>
                  <Input
                    id="productName"
                    value={formData.name}
                    onChange={(e) => updateFormData({ name: e.target.value })}
                    placeholder="Enter product name"
                  />
                </div>
                <div>
                  <Label htmlFor="brand">Brand</Label>
                  <Select value={formData.brand} onValueChange={(value) => updateFormData({ brand: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Brand" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="no-brand">No Brand</SelectItem>
                      <SelectItem value="generic">Generic</SelectItem>
                      <SelectItem value="nike">Nike</SelectItem>
                      <SelectItem value="adidas">Adidas</SelectItem>
                      <SelectItem value="zara">Zara</SelectItem>
                      <SelectItem value="h&m">H&M</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Image Upload */}
            <Card>
              <CardHeader>
                <CardTitle>Product Images *</CardTitle>
              </CardHeader>
              <CardContent>
                <ImageUpload
                  images={formData.images}
                  onImagesChange={(images: string[]) => updateFormData({ images })}
                />
              </CardContent>
            </Card>

            {/* Variants */}
            <Card>
              <CardHeader>
                <CardTitle>Product Variants</CardTitle>
              </CardHeader>
              <CardContent>
                <VariantTable
                  colors={formData.colors}
                  sizes={formData.sizes}
                  variants={formData.variants}
                  onColorsChange={(colors: string[]) => updateFormData({ colors })}
                  onSizesChange={(sizes: string[]) => updateFormData({ sizes })}
                  onVariantsChange={(variants: any[]) => updateFormData({ variants })}
                />
              </CardContent>
            </Card>

            {/* Product Description */}
            <Card>
              <CardHeader>
                <CardTitle>Product Description *</CardTitle>
              </CardHeader>
              <CardContent>
                <RichTextEditor
                  value={formData.description}
                  onChange={(description: string) => updateFormData({ description })}
                  placeholder="Describe your product in detail. Include material, fit, care instructions, and key features. Minimum 30 words required."
                />
              </CardContent>
            </Card>

            {/* Product Highlights */}
            <Card>
              <CardHeader>
                <CardTitle>Product Highlights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {formData.highlights.map((highlight: string, index: number) => (
                    <div key={index} className="flex items-start space-x-3">
                      <span className="text-muted-foreground mt-2">•</span>
                      <Input
                        value={highlight}
                        onChange={(e) => {
                          const newHighlights = [...formData.highlights];
                          newHighlights[index] = e.target.value;
                          updateFormData({ highlights: newHighlights });
                        }}
                        placeholder="Enter product highlight"
                        className="flex-1"
                      />
                      {formData.highlights.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const newHighlights = formData.highlights.filter((_: string, i: number) => i !== index);
                            updateFormData({ highlights: newHighlights });
                          }}
                        >
                          ×
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    onClick={() => updateFormData({ highlights: [...formData.highlights, ""] })}
                    className="w-full"
                  >
                    Add Highlight
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Minimum 3 highlights recommended. Include material, fit, season, etc.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content Score */}
          <div className="w-80">
            <div className="sticky top-24">
              <ContentScore
                formData={formData}
                contentScore={getContentScore()}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Actions */}
      <div className="sticky bottom-0 bg-background border-t border-border p-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="text-sm text-muted-foreground">
            Auto-saving enabled
          </div>
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={handleSaveDraft}
              disabled={createProductMutation.isPending}
            >
              <Save className="w-4 h-4 mr-2" />
              Save Draft
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={createProductMutation.isPending}
            >
              <Send className="w-4 h-4 mr-2" />
              Submit for Review
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
