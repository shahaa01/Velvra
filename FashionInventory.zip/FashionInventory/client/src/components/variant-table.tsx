import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, Plus } from "lucide-react";

interface Color {
  name: string;
  hex: string;
}

interface Size {
  size: string;
  bodyPart: string;
  unit: string;
  value: number;
}

interface Variant {
  color: string;
  size: string;
  price: number;
  specialPrice?: number;
  stock: number;
  sku: string;
  available: boolean;
}

interface VariantTableProps {
  colors: Color[];
  sizes: Size[];
  variants: Variant[];
  onColorsChange: (colors: Color[]) => void;
  onSizesChange: (sizes: Size[]) => void;
  onVariantsChange: (variants: Variant[]) => void;
}

export function VariantTable({ colors, sizes, variants, onColorsChange, onSizesChange, onVariantsChange }: VariantTableProps) {
  
  // Auto-generate variant combinations when colors or sizes change
  useEffect(() => {
    const combinations: Variant[] = [];
    const validColors = colors.filter(c => c.name.trim());
    const validSizes = sizes.filter(s => s.size && s.bodyPart);

    validColors.forEach(color => {
      validSizes.forEach(size => {
        // Check if this combination already exists
        const existing = variants.find(v => v.color === color.name && v.size === size.size);
        if (existing) {
          combinations.push(existing);
        } else {
          combinations.push({
            color: color.name,
            size: size.size,
            price: 0,
            specialPrice: undefined,
            stock: 0,
            sku: `${color.name.substring(0, 3).toUpperCase()}-${size.size}`,
            available: true
          });
        }
      });
    });

    onVariantsChange(combinations);
  }, [colors, sizes]);

  const addColor = () => {
    onColorsChange([...colors, { name: "", hex: "#000000" }]);
  };

  const removeColor = (index: number) => {
    const newColors = colors.filter((_, i) => i !== index);
    onColorsChange(newColors);
  };

  const updateColor = (index: number, updates: Partial<Color>) => {
    const newColors = [...colors];
    newColors[index] = { ...newColors[index], ...updates };
    onColorsChange(newColors);
  };

  const addSize = () => {
    onSizesChange([...sizes, { size: "", bodyPart: "", unit: "cm", value: 0 }]);
  };

  const removeSize = (index: number) => {
    const newSizes = sizes.filter((_, i) => i !== index);
    onSizesChange(newSizes);
  };

  const updateSize = (index: number, updates: Partial<Size>) => {
    const newSizes = [...sizes];
    newSizes[index] = { ...newSizes[index], ...updates };
    onSizesChange(newSizes);
  };

  const updateVariant = (index: number, updates: Partial<Variant>) => {
    const newVariants = [...variants];
    newVariants[index] = { ...newVariants[index], ...updates };
    onVariantsChange(newVariants);
  };

  return (
    <div className="space-y-6">
      {/* Color Variants */}
      <div>
        <Label className="text-sm font-medium mb-2 block">Color Family</Label>
        <div className="space-y-3">
          {colors.map((color, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 border border-border rounded-lg">
              <Input
                value={color.name}
                onChange={(e) => updateColor(index, { name: e.target.value })}
                placeholder="Color name"
                className="flex-1"
              />
              <input
                type="color"
                value={color.hex}
                onChange={(e) => updateColor(index, { hex: e.target.value })}
                className="w-10 h-10 border border-border rounded cursor-pointer"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeColor(index)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="outline" onClick={addColor} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Add Color
          </Button>
        </div>
      </div>

      {/* Size Table */}
      <div>
        <Label className="text-sm font-medium mb-2 block">Size Information</Label>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Size</TableHead>
                <TableHead>Body Part</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sizes.map((size, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <Select value={size.size} onValueChange={(value) => updateSize(index, { size: value })}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="XS">XS</SelectItem>
                        <SelectItem value="S">S</SelectItem>
                        <SelectItem value="M">M</SelectItem>
                        <SelectItem value="L">L</SelectItem>
                        <SelectItem value="XL">XL</SelectItem>
                        <SelectItem value="XXL">XXL</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select value={size.bodyPart} onValueChange={(value) => updateSize(index, { bodyPart: value })}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Chest">Chest</SelectItem>
                        <SelectItem value="Waist">Waist</SelectItem>
                        <SelectItem value="Height">Height</SelectItem>
                        <SelectItem value="Collar">Collar</SelectItem>
                        <SelectItem value="Sleeve">Sleeve</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select value={size.unit} onValueChange={(value) => updateSize(index, { unit: value })}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cm">cm</SelectItem>
                        <SelectItem value="inch">inch</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      step="0.1"
                      value={size.value}
                      onChange={(e) => updateSize(index, { value: parseFloat(e.target.value) || 0 })}
                      className="w-full"
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSize(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Button variant="outline" onClick={addSize} className="w-full mt-2">
            <Plus className="h-4 w-4 mr-2" />
            Add Size Row
          </Button>
        </div>
      </div>

      {/* Variants Combination Table */}
      {variants.length > 0 && (
        <div>
          <Label className="text-sm font-medium mb-2 block">Variant Combinations</Label>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Color</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Special Price</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {variants.map((variant, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{variant.color}</TableCell>
                    <TableCell>{variant.size}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        step="0.01"
                        value={variant.price}
                        onChange={(e) => updateVariant(index, { price: parseFloat(e.target.value) || 0 })}
                        className="w-full"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        step="0.01"
                        value={variant.specialPrice || ""}
                        onChange={(e) => updateVariant(index, { specialPrice: parseFloat(e.target.value) || undefined })}
                        className="w-full"
                        placeholder="Optional"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        value={variant.stock}
                        onChange={(e) => updateVariant(index, { stock: parseInt(e.target.value) || 0 })}
                        className="w-full"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        value={variant.sku}
                        onChange={(e) => updateVariant(index, { sku: e.target.value })}
                        className="w-full"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          checked={variant.available}
                          onCheckedChange={(checked) => updateVariant(index, { available: !!checked })}
                        />
                        <span className={`text-sm ${variant.available ? 'text-green-600' : 'text-muted-foreground'}`}>
                          {variant.available ? '✅' : '❌'}
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
}