import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Bold, Italic, Underline, List, ListOrdered, Image } from "lucide-react";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function RichTextEditor({ value, onChange, placeholder }: RichTextEditorProps) {
  const [isEditing, setIsEditing] = useState(false);

  const getWordCount = (text: string) => {
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  };

  const wordCount = getWordCount(value);

  return (
    <div>
      <div className="border border-border rounded-lg">
        {/* Toolbar */}
        <div className="flex items-center space-x-1 p-2 border-b border-border bg-muted/25 rounded-t-lg">
          <Button variant="ghost" size="sm" title="Bold">
            <Bold className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" title="Italic">
            <Italic className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" title="Underline">
            <Underline className="h-4 w-4" />
          </Button>
          <div className="w-px h-6 bg-border"></div>
          <Button variant="ghost" size="sm" title="Bullet List">
            <List className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" title="Numbered List">
            <ListOrdered className="h-4 w-4" />
          </Button>
          <div className="w-px h-6 bg-border"></div>
          <Button variant="ghost" size="sm" title="Insert Image">
            <Image className="h-4 w-4" />
          </Button>
        </div>

        {/* Editor Content */}
        <Textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="border-0 rounded-none rounded-b-lg resize-none focus-visible:ring-0"
          rows={6}
          placeholder={placeholder}
          onFocus={() => setIsEditing(true)}
          onBlur={() => setIsEditing(false)}
        />
      </div>

      {/* Word Count */}
      <div className="flex justify-between items-center mt-2">
        <span className="text-xs text-muted-foreground">Minimum 30 words required</span>
        <span className={`text-xs ${wordCount >= 30 ? 'text-green-600' : 'text-muted-foreground'}`}>
          {wordCount} words
        </span>
      </div>
    </div>
  );
}