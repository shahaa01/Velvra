import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronDown, Circle } from "lucide-react";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface CategoryNode {
  name: string;
  path: string[];
  children?: CategoryNode[];
  expanded?: boolean;
}

interface CategorySelectorProps {
  selectedCategory: string[];
  onCategorySelect: (category: string[]) => void;
}

const categoryTree: CategoryNode[] = [
  {
    name: "Fashion",
    path: ["Fashion"],
    children: [
      {
        name: "Women",
        path: ["Fashion", "Women"],
        children: [
          {
            name: "Clothing",
            path: ["Fashion", "Women", "Clothing"],
            children: [
              {
                name: "Jackets & Coats",
                path: ["Fashion", "Women", "Clothing", "Jackets & Coats"],
                children: [
                  { name: "Denim Jackets", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Denim Jackets"] },
                  { name: "Leather Jackets", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Leather Jackets"] },
                  { name: "Bomber Jackets", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Bomber Jackets"] },
                  { name: "Lightweight Jackets", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Lightweight Jackets"] },
                  { name: "Winter Jackets & Coats", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Winter Jackets & Coats"] },
                  { name: "Rain Coats & Trenches", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Rain Coats & Trenches"] },
                  { name: "Down Jackets", path: ["Fashion", "Women", "Clothing", "Jackets & Coats", "Down Jackets"] }
                ]
              },
              { name: "Dresses", path: ["Fashion", "Women", "Clothing", "Dresses"] },
              { name: "Tops & Blouses", path: ["Fashion", "Women", "Clothing", "Tops & Blouses"] },
              { name: "Pants & Leggings", path: ["Fashion", "Women", "Clothing", "Pants & Leggings"] }
            ]
          },
          { name: "Accessories", path: ["Fashion", "Women", "Accessories"] },
          { name: "Shoes", path: ["Fashion", "Women", "Shoes"] }
        ]
      },
      {
        name: "Men",
        path: ["Fashion", "Men"],
        children: [
          {
            name: "Clothing",
            path: ["Fashion", "Men", "Clothing"],
            children: [
              {
                name: "Jackets & Coats",
                path: ["Fashion", "Men", "Clothing", "Jackets & Coats"],
                children: [
                  { name: "Denim Jackets", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Denim Jackets"] },
                  { name: "Leather Jackets", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Leather Jackets"] },
                  { name: "Bomber Jackets", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Bomber Jackets"] },
                  { name: "Lightweight Jackets", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Lightweight Jackets"] },
                  { name: "Winter Jackets & Coats", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Winter Jackets & Coats"] },
                  { name: "Rain Coats & Trenches", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Rain Coats & Trenches"] },
                  { name: "Down Jackets", path: ["Fashion", "Men", "Clothing", "Jackets & Coats", "Down Jackets"] }
                ]
              },
              { name: "Shirts", path: ["Fashion", "Men", "Clothing", "Shirts"] },
              { name: "Pants & Jeans", path: ["Fashion", "Men", "Clothing", "Pants & Jeans"] },
              { name: "T-Shirts & Polos", path: ["Fashion", "Men", "Clothing", "T-Shirts & Polos"] }
            ]
          },
          { name: "Accessories", path: ["Fashion", "Men", "Accessories"] },
          { name: "Shoes", path: ["Fashion", "Men", "Shoes"] }
        ]
      },
      {
        name: "Girls",
        path: ["Fashion", "Girls"],
        children: [
          {
            name: "Clothing",
            path: ["Fashion", "Girls", "Clothing"],
            children: [
              { name: "Jackets & Coats", path: ["Fashion", "Girls", "Clothing", "Jackets & Coats"] },
              { name: "Dresses", path: ["Fashion", "Girls", "Clothing", "Dresses"] },
              { name: "Tops", path: ["Fashion", "Girls", "Clothing", "Tops"] }
            ]
          },
          { name: "Accessories", path: ["Fashion", "Girls", "Accessories"] },
          { name: "Shoes", path: ["Fashion", "Girls", "Shoes"] }
        ]
      },
      {
        name: "Boys",
        path: ["Fashion", "Boys"],
        children: [
          {
            name: "Clothing",
            path: ["Fashion", "Boys", "Clothing"],
            children: [
              { name: "Jackets & Coats", path: ["Fashion", "Boys", "Clothing", "Jackets & Coats"] },
              { name: "Shirts", path: ["Fashion", "Boys", "Clothing", "Shirts"] },
              { name: "Pants", path: ["Fashion", "Boys", "Clothing", "Pants"] }
            ]
          },
          { name: "Accessories", path: ["Fashion", "Boys", "Accessories"] },
          { name: "Shoes", path: ["Fashion", "Boys", "Shoes"] }
        ]
      },
      {
        name: "Unisex",
        path: ["Fashion", "Unisex"],
        children: [
          { name: "Clothing", path: ["Fashion", "Unisex", "Clothing"] },
          { name: "Accessories", path: ["Fashion", "Unisex", "Accessories"] },
          { name: "Shoes", path: ["Fashion", "Unisex", "Shoes"] }
        ]
      },
      {
        name: "Kids Unisex",
        path: ["Fashion", "Kids Unisex"],
        children: [
          { name: "Clothing", path: ["Fashion", "Kids Unisex", "Clothing"] },
          { name: "Accessories", path: ["Fashion", "Kids Unisex", "Accessories"] },
          { name: "Shoes", path: ["Fashion", "Kids Unisex", "Shoes"] }
        ]
      }
    ]
  }
];

export function CategorySelector({ selectedCategory, onCategorySelect }: CategorySelectorProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [recentCategories, setRecentCategories] = useLocalStorage<string[]>("recent-categories", []);

  const toggleNode = (path: string[]) => {
    const pathKey = path.join(">");
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(pathKey)) {
      newExpanded.delete(pathKey);
    } else {
      newExpanded.add(pathKey);
    }
    setExpandedNodes(newExpanded);
  };

  const selectCategory = (path: string[]) => {
    onCategorySelect(path);
    
    // Add to recent categories
    const pathString = path.join(" > ");
    const newRecent = [pathString, ...recentCategories.filter((c: string) => c !== pathString)].slice(0, 5);
    setRecentCategories(newRecent);
  };

  const renderCategoryNode = (node: CategoryNode, depth = 0) => {
    const pathKey = node.path.join(">");
    const isExpanded = expandedNodes.has(pathKey);
    const hasChildren = node.children && node.children.length > 0;

    return (
      <div key={pathKey} className={`${depth > 0 ? "ml-6" : ""}`}>
        <div className="flex items-center justify-between p-3 hover:bg-muted/50 cursor-pointer border-b border-border/50 last:border-b-0 tree-item">
          <div className="flex items-center space-x-2" onClick={() => hasChildren && toggleNode(node.path)}>
            {hasChildren ? (
              isExpanded ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )
            ) : (
              <Circle className="h-2 w-2 text-muted-foreground" />
            )}
            <span className="text-sm font-medium">{node.name}</span>
          </div>
          {!hasChildren && (
            <Button
              size="sm"
              onClick={() => selectCategory(node.path)}
              className="h-7 px-3 text-xs"
            >
              Select
            </Button>
          )}
        </div>
        {hasChildren && isExpanded && (
          <div className="bg-muted/25 animate-slide-in">
            {node.children?.map(child => renderCategoryNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Tabs defaultValue="browse">
      <TabsList className="mb-4">
        <TabsTrigger value="browse">Browse Categories</TabsTrigger>
        <TabsTrigger value="recent">Recently Used</TabsTrigger>
      </TabsList>

      <TabsContent value="browse">
        <div className="max-h-64 overflow-y-auto border border-border rounded-lg">
          {categoryTree.map(node => renderCategoryNode(node))}
        </div>
      </TabsContent>

      <TabsContent value="recent">
        <div className="space-y-2">
          <div className="text-sm text-muted-foreground mb-3">Your recently selected categories</div>
          {recentCategories.length > 0 ? (
            recentCategories.map((categoryPath: string, index: number) => (
              <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50">
                <span className="text-sm">{categoryPath}</span>
                <Button
                  size="sm"
                  onClick={() => selectCategory(categoryPath.split(" > "))}
                  className="h-7 px-3 text-xs"
                >
                  Select
                </Button>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No recently used categories
            </div>
          )}
        </div>
      </TabsContent>
    </Tabs>
  );
}