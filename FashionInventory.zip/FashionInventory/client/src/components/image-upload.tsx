import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CloudUpload, Edit, Trash2, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ImageData {
  url: string;
  isWhiteBackground?: boolean;
}

interface ImageUploadProps {
  images: ImageData[];
  onImagesChange: (images: ImageData[]) => void;
}

export function ImageUpload({ images, onImagesChange }: ImageUploadProps) {
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [whiteBgImage, setWhiteBgImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const whiteBgInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result && images.length < 7) {
          const newImage: ImageData = {
            url: e.target.result as string,
            isWhiteBackground: false
          };
          onImagesChange([...images, newImage]);
        }
      };
      reader.readAsDataURL(file);
    });
    
    if (event.target) {
      event.target.value = '';
    }
  };

  const handleWhiteBgUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setWhiteBgImage(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index);
    onImagesChange(newImages);
  };

  const editImage = (index: number) => {
    setEditingIndex(index);
    setShowEditModal(true);
  };

  const removeWhiteBgImage = () => {
    setWhiteBgImage(null);
  };

  return (
    <div className="space-y-6">
      {/* Guidelines */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <div className="font-medium mb-1">Image Guidelines:</div>
          <ul className="text-xs space-y-1">
            <li>• Minimum size: 480x480px</li>
            <li>• Maximum file size: 100MB</li>
            <li>• Formats: JPG, PNG</li>
            <li>• Upload up to 7 images</li>
          </ul>
        </AlertDescription>
      </Alert>

      {/* White Background Image */}
      <div>
        <label className="block text-sm font-medium mb-2">
          White Background Image (Recommended for Cover)
        </label>
        <div
          className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary hover:bg-primary/5 transition-colors cursor-pointer"
          onClick={() => whiteBgInputRef.current?.click()}
        >
          {!whiteBgImage ? (
            <div>
              <CloudUpload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <div className="text-sm text-muted-foreground">Click to upload white background image</div>
            </div>
          ) : (
            <div className="relative">
              <img src={whiteBgImage} alt="White background product" className="h-32 w-auto mx-auto rounded" />
              <Button
                variant="destructive"
                size="sm"
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                onClick={(e) => {
                  e.stopPropagation();
                  removeWhiteBgImage();
                }}
              >
                ×
              </Button>
            </div>
          )}
          <input
            ref={whiteBgInputRef}
            type="file"
            className="hidden"
            accept="image/*"
            onChange={handleWhiteBgUpload}
          />
        </div>
      </div>

      {/* Main Product Images */}
      <div>
        <label className="block text-sm font-medium mb-2">Product Images</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {images.map((image, index) => (
            <div key={index} className="relative group">
              <div className="aspect-square border-2 border-border rounded-lg overflow-hidden hover:border-primary transition-colors">
                <img src={image.url} alt={`Product ${index + 1}`} className="w-full h-full object-cover cursor-pointer" />
              </div>
              
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all rounded-lg flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity space-x-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => editImage(index)}
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => removeImage(index)}
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>

              {/* Quick delete button */}
              <Button
                variant="destructive"
                size="sm"
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removeImage(index)}
              >
                ×
              </Button>
            </div>
          ))}

          {/* Upload slot */}
          {images.length < 7 && (
            <div
              className="aspect-square border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-primary hover:bg-primary/5 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <CloudUpload className="h-6 w-6 text-muted-foreground mb-2" />
              <span className="text-xs text-muted-foreground">Add Image</span>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept="image/*"
                multiple
                onChange={handleImageUpload}
              />
            </div>
          )}
        </div>
      </div>

      {/* Image Edit Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Image</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {editingIndex !== null && (
              <div className="text-center">
                <img 
                  src={images[editingIndex]?.url} 
                  alt="Editing" 
                  className="max-h-64 mx-auto rounded border"
                />
              </div>
            )}
            
            <div className="flex flex-wrap gap-2">
              <Button>Crop</Button>
              <Button variant="outline">Remove Background</Button>
              <Button variant="outline">Rotate</Button>
              <Button variant="outline">Mirror</Button>
              <Button variant="outline">Reset</Button>
            </div>
            
            <div className="bg-muted rounded-lg p-4 text-center">
              <div className="text-muted-foreground mb-2">Image editing tools will be integrated here</div>
              <div className="text-xs text-muted-foreground">
                Placeholder for image editing interface (Cropper.js integration)
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}