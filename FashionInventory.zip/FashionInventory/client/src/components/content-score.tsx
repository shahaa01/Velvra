import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Circle } from "lucide-react";

interface ContentScoreProps {
  formData: {
    name: string;
    category: string[];
    brand: string;
    description: string;
    highlights: string[];
    images: Array<{ url: string; isWhiteBackground?: boolean }>;
    colors: Array<{ name: string; hex: string }>;
    sizes: Array<{ size: string; bodyPart: string; unit: string; value: number }>;
  };
  contentScore: number;
}

export function ContentScore({ formData, contentScore }: ContentScoreProps) {
  const getWordCount = (text: string) => {
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  };

  const criteria = [
    {
      section: "Basic Info",
      items: [
        {
          label: "Product Name",
          completed: formData.name.length > 0
        },
        {
          label: "3+ Images",
          completed: formData.images.length >= 3
        }
      ]
    },
    {
      section: "Product Specification",
      items: [
        {
          label: "Brand",
          completed: formData.brand.length > 0
        },
        {
          label: "Category",
          completed: formData.category.length > 0
        }
      ]
    },
    {
      section: "Price & Variants",
      items: [
        {
          label: "Color + Size + Stock",
          completed: formData.colors.length > 0 && formData.sizes.length > 0
        }
      ]
    },
    {
      section: "Product Description",
      items: [
        {
          label: "30+ Words",
          completed: getWordCount(formData.description) >= 30
        },
        {
          label: "3+ Highlights",
          completed: formData.highlights.filter(h => h.trim()).length >= 3
        }
      ]
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Content Score</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Overall Progress</span>
            <span className="text-sm font-medium text-primary">{contentScore}%</span>
          </div>
          <Progress value={contentScore} className="h-2" />
        </div>

        {/* Checklist */}
        <div className="space-y-4">
          {criteria.map((section, sectionIndex) => (
            <div key={sectionIndex}>
              <h4 className="text-sm font-medium mb-2">{section.section}</h4>
              <div className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <div
                    key={itemIndex}
                    className={`flex items-center space-x-3 p-2 rounded-lg border transition-colors ${
                      item.completed 
                        ? 'bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800' 
                        : 'border-border'
                    }`}
                  >
                    {item.completed ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <Circle className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="text-sm">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}