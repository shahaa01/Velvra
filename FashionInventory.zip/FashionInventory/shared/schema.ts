import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").array().notNull(),
  brand: text("brand"),
  description: text("description"),
  highlights: text("highlights").array(),
  images: jsonb("images").$type<Array<{ url: string; isWhiteBackground?: boolean }>>(),
  colors: jsonb("colors").$type<Array<{ name: string; hex: string }>>(),
  sizes: jsonb("sizes").$type<Array<{ size: string; bodyPart: string; unit: string; value: number }>>(),
  variants: jsonb("variants").$type<Array<{ color: string; size: string; price: number; specialPrice?: number; stock: number; sku: string; available: boolean }>>(),
  status: text("status").notNull().default("draft"), // draft, submitted, approved, rejected
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateProductSchema = insertProductSchema.partial();

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type UpdateProduct = z.infer<typeof updateProductSchema>;
